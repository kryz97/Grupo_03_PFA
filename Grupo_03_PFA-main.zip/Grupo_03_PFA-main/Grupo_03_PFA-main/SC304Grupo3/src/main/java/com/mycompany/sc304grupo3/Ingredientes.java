/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sc304grupo3;
import javax.swing.JOptionPane;
/**
 *
 * @author chris
 */
public class Ingredientes {
    private int ID;
    private String nombre;
    private double costoIngredientes;
    private double precio;

    public Ingredientes() {
        
    }

    public Ingredientes(int ID, String nombre, double costoIngredientes, double precio) {
        this.ID = ID;
        this.nombre = nombre;
        this.costoIngredientes = costoIngredientes;
        this.precio = precio;
    }

    public int getId() {
        return ID;
    }

    public void setId(int ID) {
        this.ID = ID;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getCosto() {
        return costoIngredientes;
    }

    public void setCosto(double costoIngredientes) {
        this.costoIngredientes= costoIngredientes;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void solicitarDatos() {
        // Utilizamos JOptionPane para solicitar los datos al usuario
        this.ID = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del platillo:"));
        this.nombre = JOptionPane.showInputDialog("Ingrese el nombre del platillo:");
        this.costoIngredientes = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el costo de los ingredientes del platillo:"));
        this.precio = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el precio del platillo:"));
    }

    @Override
    public String toString() {
        return "ID: " + ID + "\nNombre: " + nombre + "\nCosto: $" + costoIngredientes + "\nPrecio: $" + precio;
    }
}
