/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.sc304grupo3;

/**
 *
 * @author chris
 */
public class SC304Grupo3 {

    public static void main(String[] args) {
        //Llamar la clase Menu 
        Menu Menu =new Menu();
        Menu.iniciar();
    }
}

